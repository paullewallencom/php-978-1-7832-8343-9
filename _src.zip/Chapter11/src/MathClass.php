<?php

class MathClass
{
    private function addition($a, $b)
    {
        return $a + $b;
    }

    protected static function subtraction($a, $b)
    {
        return $a - $b;
    }
}

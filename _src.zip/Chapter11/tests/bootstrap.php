<?php
const WORDPRESS_LOCATION = 'C:/projects/wordpress';
require_once __DIR__ ."/../vendor/autoload.php";
require_once __DIR__ ."/../vendor/antecedent/patchwork/Patchwork.php";
const STACK_END_POINT_URL = "http://api.stackexchange.com";
const STACK_API_VERSION = "2.1";


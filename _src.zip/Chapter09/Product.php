<?php

class Product
{
    public $product_id;
    public $title;
    public $description;
    public $price_net;

}

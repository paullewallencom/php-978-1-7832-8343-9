<?php

class PDOMock extends PDO {
    public function __construct() {}
}
<?php

class InvoiceItem
{
    public $invoice_item_id;
    public $invoice_id;
    public $product_id;
    public $quantity;
    public $price;

}

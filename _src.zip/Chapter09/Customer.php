<?php

class Customer
{
    public $customer_id;
    public $firstname;
    public $lastname;
    public $email;

}

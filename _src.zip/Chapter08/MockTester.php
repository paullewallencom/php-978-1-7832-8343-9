<?php

class MockTester
{
    public function getOne()
    {
        return 1;
    }

    public function getTwo()
    {
        return 2;
    }
}

<?php

namespace Util;

class Mail
{
    public function setEmailFrom($emailFrom) {}
    public function setEmailTo($emailTo) {}
    public function setTitle($title) {}
    public function setBody($body) {}
    public function send() {}

}
